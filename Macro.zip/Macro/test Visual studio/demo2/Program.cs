﻿using System;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.IO;

namespace ExcelInteraction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Create an instance of Excel Application
            Excel.Application excelApp = null;
            Excel.Workbook sourceWorkbook = null;
            Excel.Workbook destinationWorkbook = null;
            Excel.Worksheet sourceWorksheet = null;
            Excel.Worksheet destinationSheet1 = null;
            Excel.Worksheet destinationSheet2 = null;

            try
            {
                excelApp = new Excel.Application();
                excelApp.Visible = true;

                // Open the source workbook (change the file path to your source Excel file)
                sourceWorkbook = excelApp.Workbooks.Open(@"C:\Users\psalunkhe\Desktop\Macro\test Visual studio\ExcelDemo\test.xlsx");

                // Check if the destination workbook exists
                string destinationFilePath = @"C:\Users\psalunkhe\Desktop\Macro\test Visual studio\ExcelDemo\destinationWorkbook.xlsx";
                if (File.Exists(destinationFilePath))
                {
                    destinationWorkbook = excelApp.Workbooks.Open(destinationFilePath);
                }
                else
                {
                    // Create a new destination workbook if it doesn't exist
                    destinationWorkbook = excelApp.Workbooks.Add();
                }

                // Get reference to the source worksheet
                sourceWorksheet = (Excel.Worksheet)sourceWorkbook.Sheets["Sheet1"];

                // Get references to the destination worksheets
                destinationSheet1 = (Excel.Worksheet)destinationWorkbook.Sheets.Add();
                destinationSheet1.Name = "Initial"; // Name the first destination sheet
                destinationSheet2 = (Excel.Worksheet)destinationWorkbook.Sheets.Add();
                destinationSheet2.Name = "remove_Redendant_column"; // Name the second destination sheet

                // Copy data and formatting from source to first destination worksheet
                sourceWorksheet.UsedRange.Copy(destinationSheet1.Range["A1"]);

                // Copy only specific columns from source to second destination worksheet
                int[] columnsToCopy = { 1, 2, 3, 4, 5, 6 }; // Define the columns you want to copy
                int destinationColumn = 1; // Specify the starting column in the destination sheet

                foreach (int column in columnsToCopy)
                {
                    Excel.Range sourceColumn = sourceWorksheet.Columns[column];
                    Excel.Range destinationColumnRange = destinationSheet2.Cells[1, destinationColumn];

                    sourceColumn.Copy(destinationColumnRange);
                    destinationColumn++;
                }

                // Remove unwanted columns
                int[] unwantedColumns = { 7 }; // Define the indices of unwanted columns
                foreach (int column in unwantedColumns)
                {
                    Excel.Range columnToRemove = destinationSheet2.Columns[column];
                    columnToRemove.Delete();
                }

                // Add extra columns "Enhanacment(Y/N)" and "Remarks"
                destinationSheet2.Cells[1, destinationColumn].Value = "Enhanacment(Y/N)";
                destinationSheet2.Cells[1, destinationColumn + 1].Value = "Remarks";

                // Set the format of destination cells in both sheets to General
                destinationSheet1.Cells.NumberFormat = "General";
                destinationSheet2.Cells.NumberFormat = "General";

                // Add borders to all cells in both sheets
                destinationSheet1.UsedRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                destinationSheet2.UsedRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;

                // Remove unwanted rows from the bottom in both sheets
                int lastRow1 = destinationSheet1.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row;
                int numRowsToRemove1 = destinationSheet1.Rows.Count - lastRow1;
                if (numRowsToRemove1 > 0)
                {
                    destinationSheet1.Rows[lastRow1 + 1].Resize[numRowsToRemove1].Delete();
                }

                int lastRow2 = destinationSheet2.Cells.SpecialCells(Excel.XlCellType.xlCellTypeLastCell).Row;
                int numRowsToRemove2 = destinationSheet2.Rows.Count - lastRow2;
                if (numRowsToRemove2 > 0)
                {
                    destinationSheet2.Rows[lastRow2 + 1].Resize[numRowsToRemove2].Delete();
                }

                // Save the destination workbook
                destinationWorkbook.SaveAs(@"C:\Users\psalunkhe\Desktop\Macro\test Visual studio\ExcelDemo\destinationWorkbook.xlsx", Excel.XlFileFormat.xlWorkbookDefault);

                Console.WriteLine("Data copied successfully to two sheets in the destination workbook.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
            finally
            {
                // Close and release resources
                if (sourceWorksheet != null) Marshal.ReleaseComObject(sourceWorksheet);
                if (destinationSheet1 != null) Marshal.ReleaseComObject(destinationSheet1);
                if (destinationSheet2 != null) Marshal.ReleaseComObject(destinationSheet2);
                if (sourceWorkbook != null)
                {
                    sourceWorkbook.Close(false);
                    Marshal.ReleaseComObject(sourceWorkbook);
                }
                if (destinationWorkbook != null)
                {
                    destinationWorkbook.Close(true);
                    Marshal.ReleaseComObject(destinationWorkbook);
                }
                if (excelApp != null)
                {
                    excelApp.Quit();
                    Marshal.ReleaseComObject(excelApp);
                }
            }
        }
    }
}