﻿using System;
using System.IO;
using System.Net;

namespace FileZillaLibrary
{
    public class FileZillaClient
    {
        private const string FtpServer = "support.e-emphasys.com";
        private const string FtpUsername = "extendftp";
        private const string FtpPassword = "eXte$d@2@!6";

      
        public void DownloadFile()
        {

            string remoteFilePath = "/E50C_1_E501/documents/100975.docx​"; // Hardcoded path to the remote file
            string localDirectory = @"C:\Users\psalunkhe\Desktop\Macro\test Visual studio\download"; // Hardcoded local directory path
            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Credentials = new NetworkCredential(FtpUsername, FtpPassword);
                    client.DownloadFile($"ftp://{FtpServer}/{remoteFilePath}", Path.Combine(localDirectory, Path.GetFileName(remoteFilePath)));
                    Console.WriteLine("File downloaded successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }
    }
}
