﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Office = Microsoft.Office.Core;
using Microsoft.Office.Tools.Excel;
using static System.Net.Mime.MediaTypeNames;

namespace ExcelAddIn1
{
    public partial class ThisAddIn
    {
        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {
            OpenExcelFile(@"C:\Users\psalunkhe\Desktop\Macro\test Visual studio\ExcelDemo\test.xlsx");
        }

        /*   private void OpenExcelFile(string filePath)
           {
               Excel.Application excelApp = this.Application;
               Excel.Workbook workbook = null;

               try
               {
                   workbook = excelApp.Workbooks.Open(filePath);
                   foreach (Excel.Worksheet worksheet in workbook.Worksheets)
                   {
                       // Set the format of all cells to General
                       worksheet.Cells.NumberFormat = "General";

                       // Find the Issue ID column (assuming it's in the first row)
                   //    Excel.Range issueIdColumn = worksheet.Rows[1].Find("IssueID", Type.Missing, Excel.XlFindLookIn.xlValues, Excel.XlLookAt.xlWhole, Excel.XlSearchOrder.xlByColumns, Excel.XlSearchDirection.xlNext, false, Type.Missing, Type.Missing);

                      /* if (issueIdColumn != null)
                       {
                           // Get the column index of the Issue ID column
                           int columnIndex = issueIdColumn.Column;

                           // Get the range of the Issue ID column (excluding the header)
                           Excel.Range issueIdRange = worksheet.Columns[columnIndex].Offset[1, 0].Resize[worksheet.Rows.Count - 1, 1];

                           // Read values from the Issue ID column into an array
                           object[,] issueIdValues = issueIdRange.Value;

                           // Extract values from the array into a string array
                           string[] issueIds = new string[issueIdValues.GetLength(0)];
                           for (int i = 0; i < issueIdValues.GetLength(0); i++)
                           {
                               issueIds[i] = Convert.ToString(issueIdValues[i + 1, 1]);
                           }

                           // Now 'issueIds' array contains the values of the Issue ID column
                       }
                       else
                       {
                           System.Windows.Forms.MessageBox.Show("Issue ID column not found.");
                       }
                   }
               }
               catch (Exception ex)
               {
                   // Handle error if file cannot be opened
                   System.Windows.Forms.MessageBox.Show("Error opening Excel file: " + ex.Message);
               }
           }*/

        private void OpenExcelFile(string filePath)
        {
            Excel.Application excelApp = this.Application;
            Excel.Workbook workbook = null;

            try
            {
                // Set Excel application visible
                excelApp.Visible = true;

                workbook = excelApp.Workbooks.Open(filePath);
                foreach (Excel.Worksheet worksheet in workbook.Worksheets)
                {
                    // Set the format of all cells to General
                    worksheet.Cells.NumberFormat = "General";

                    // Your other logic here
                }
            }
            catch (Exception ex)
            {
                // Handle error if file cannot be opened
                System.Windows.Forms.MessageBox.Show("Error opening Excel file: " + ex.Message);
            }
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }
        
        #endregion 
    }
}
