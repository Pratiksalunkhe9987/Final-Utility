﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace ExcelAddIn1
{
    internal class FileZillaClient
    {
        private const string FtpServer = "support.e-emphasys.com";
        private const string FtpUsername = "extendftp";
        private const string FtpPassword = "eXte$d@2@!6";


        public void DownloadFile()
        {
            string remoteFilePath = "E50C_1_E501/documents/100010.doc"; // Corrected remote file path
            string localDirectory = @"C:\Users\psalunkhe\Desktop\Macro\download";

            try
            {
                using (WebClient client = new WebClient())
                {
                    client.Credentials = new NetworkCredential(FtpUsername, FtpPassword);
                    client.DownloadFile($"ftp://{FtpServer}/{remoteFilePath}", Path.Combine(localDirectory, "100010.doc"));
                    Console.WriteLine("File downloaded successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An error occurred: {ex.Message}");
            }
        }

    }
}
