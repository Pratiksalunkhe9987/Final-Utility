﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAddInbulletins
{
    public static class DirectoryPath
    {
        public static string Maindirectory { get; set; }

        public static string DownloadSD { get; set; }

        public static string txtdirectory { get; set; }

        public static string AbsentSD { get; set; }

        public static string proximafiledirectory { get; set; }

        public static string finalbulletins { get; set; }

         static DirectoryPath()
         {
            /*
             //original copy of excel from ecare
             Maindirectory = @"C:\Users\psalunkhe\Desktop\Bulletinstest1.xlsx";
             //location to download SD
             DownloadSD = @"C:\Users\psalunkhe\Desktop\Macro\download";
             //location to download sorted issue id .txt file
             txtdirectory = @"C:\Users\psalunkhe\Desktop\Macro\WeeklyList.txt";
             //location to save the excel with absent SD mark 
             AbsentSD = @"C:\Users\psalunkhe\Desktop\Macro\WeeklyList.xlsx";
             //location from where you pick the proxima generated txt file
             proximafiledirectory = @"C:\Users\psalunkhe\Desktop\Macro\Weekly List";
             //final bulletins location
             finalbulletins = @"C:\Users\psalunkhe\Desktop\Macro\Final Bulletins";
            */

            
            string userName = Environment.UserName;

            // Get the desktop directory for the current user
            string desktopDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            // Construct paths based on the desktop directory
            Maindirectory = Path.Combine(desktopDirectory, "Bulletinstest1.xlsx");
            DownloadSD = Path.Combine(desktopDirectory, "Macro", "download");
            txtdirectory = Path.Combine(desktopDirectory, "Macro", "WeeklyList.txt");
            AbsentSD = Path.Combine(desktopDirectory, "Macro", "WeeklyList.xlsx");
            proximafiledirectory = Path.Combine(desktopDirectory, "Macro", "Weekly List");
            finalbulletins = Path.Combine(desktopDirectory, "Macro", "Final Bulletins");
            
        }

        /*public static void setMaindirectory()
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Store the selected file path
                    Maindirectory = openFileDialog.FileName;

                    // Use the selected file path in your application logic
                }
            }
        }*/

        /*public static void CloseAllReadOnlyWorkbooks()
        {
            // Get all running Excel processes
            Process[] processes = Process.GetProcessesByName("EXCEL");

            foreach (Process process in processes)
            {
                try
                {
                    // Attach to the Excel application instance
                    Excel.Application excelApp = (Excel.Application)System.Runtime.InteropServices.Marshal.GetActiveObject("Excel.Application");

                    foreach (Excel.Workbook workbook in excelApp.Workbooks)
                    {
                        // Check if the workbook is open in read-only mode
                        if (workbook.ReadOnly)
                        {
                            workbook.Close(false); // Close without saving changes
                        }
                    }

                    // Quit Excel application
                    excelApp.Quit();
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                }
                catch (Exception ex)
                {
                    // Handle exceptions
                }
            }
        }*/
        
    }
   
}
