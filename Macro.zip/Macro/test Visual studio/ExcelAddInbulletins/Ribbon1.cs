﻿using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;
using System;
using Excel = Microsoft.Office.Interop.Excel;
using System.Collections.Generic;
using Microsoft.Office.Interop.Word;

namespace ExcelAddInbulletins
{
    public partial class Ribbon1
    {
        List<string> list = new List<string>();
        private void Ribbon1_Load(object sender, RibbonUIEventArgs e)
        {
            //MessageBox.Show("Ribbon Loaded");
        }

        private void button1_Click(object sender, RibbonControlEventArgs e)
        {
            getsheet1 obj = new getsheet1();
            obj.CopyDataToremovecolumnWorksheet();
           
        }
     
        private void button2_Click_1(object sender, RibbonControlEventArgs e)
        {
            getweeklylistsheet obj = new getweeklylistsheet();
            obj.combinedfinalsheet();
            obj.finalformat();
           
        }

        private void button3_Click(object sender, RibbonControlEventArgs e)
        {
            getweeklylistsheet obj = new getweeklylistsheet();
            obj.FormatWeeklyListExcelFile();
            obj.AddFinalSDDownloadSheet();
        

        }

        private void button4_Click(object sender, RibbonControlEventArgs e)
        {
            //  getSheet2 obj = new getSheet2();
            // obj.CopyDataToUnderscoreSDWorksheet();
            //DirectoryPath.setMaindirectory();

        }

        private void button5_Click(object sender, RibbonControlEventArgs e)
        {
            
            addchecklist obj = new addchecklist();
            obj.AddChecklistsIfBlank();
            
        }



        private void button6_Click_1(object sender, RibbonControlEventArgs e)
        {
            Readchecklist obj = new Readchecklist();
            obj.CopyCombinedDataToNewWorkbook();
        }

        private void button7_Click(object sender, RibbonControlEventArgs e)
        {
            sheets2 obj = new sheets2();
            obj.CopyHeaderToUnderscoreSDWorksheet();
            list=obj.getpresentids();
        }

        private void button8_Click(object sender, RibbonControlEventArgs e)
        {
            getSheet3 ob = new getSheet3();
            ob.CopyHeaderToFinal_SD_Download_List(list);
        }
    }
}
