﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Microsoft.Office.Interop.Word;
using System.Windows.Forms;
using Application = Microsoft.Office.Interop.Word.Application;
using Excel = Microsoft.Office.Interop.Excel;
using System.Text.RegularExpressions;

namespace ExcelAddInbulletins
{
    internal class Readchecklist
    {
        List<string> issueIdsWithEmptyExternalText = new List<string>();
        Dictionary<string, Tuple<string, string>> updatedchecklistDictionary;
        Dictionary<string, string> checklist = new Dictionary<string, string>();
        Dictionary<string, string> instructions = new Dictionary<string, string>();

        public void UpdateChecklistExternalText(Dictionary<string, Tuple<string, string>> checklistDictionary)
        {
            updatedchecklistDictionary = new Dictionary<string, Tuple<string, string>>(checklistDictionary);

            // Iterate through the checklistDictionary
            foreach (var kvp in checklistDictionary)
            {
                string issueId = kvp.Key;
                string externalText = kvp.Value.Item1;

                // Check if externalText is null or empty
                if (string.IsNullOrEmpty(externalText))
                {
                    // If externalText is null or empty, add the issue ID to the list
                    issueIdsWithEmptyExternalText.Add(issueId);
                }
            }

            // Now you can use issueIdsWithEmptyExternalText list as needed
            // For example, you could print the issue IDs:
            foreach (string issueId in issueIdsWithEmptyExternalText)
            {
                Console.WriteLine($"Issue ID with empty external text: {issueId}");
            }

            GetExternalChecklist(issueIdsWithEmptyExternalText);
            GetSpecialInstructions(issueIdsWithEmptyExternalText);
            //AddExternalChecklist(checklist, instructions);
            AddExternalChecklist(checklist,instructions);


        }
        
        /*public void GetExternalChecklistSummary(List<string> issueIds)
        {
            string folderPath = DirectoryPath.DownloadSD;
            Application wordApp = new Application();

            foreach (string issueId in issueIds)
            {
                string filePath = Path.Combine(folderPath, $"{issueId}.docx"); // Assuming the file extension is .doc
                if (File.Exists(filePath))
                {
                    
                    try
                    {
                        Document doc = wordApp.Documents.Open(filePath);
                        string fileContents = ReadContentAfterExternalChecklist(doc);
                        doc.Close(WdSaveOptions.wdDoNotSaveChanges);
                        updatedchecklistDictionary[issueId] = Tuple.Create(fileContents, "internal Checklist");
                    }
                    catch (Exception ex)
                    {
                        updatedchecklistDictionary[issueId] = Tuple.Create($"Error: {ex.Message}", "");
                    }
                }
                else
                {
                    updatedchecklistDictionary[issueId] = Tuple.Create("Summary not available", "");
                }
            }

            wordApp.Quit();

        }*/

        /*private string ReadContentAfterExternalChecklist(Document doc)
        {
            string content = "";
            bool startReading = false;

            foreach (Paragraph para in doc.Paragraphs)
            {
                string text = para.Range.Text.Trim();

                if (startReading)
                {
                    // Check if the label is found to stop reading
                    if (IsLabel(text))
                    {
                        break;
                    }

                    // Append text to content if reading has started
                    content += text + "\n";
                }

                // Check for the label indicating the start of the relevant content
                if (text.ToLower().StartsWith("external checklist:"))
                {
                    startReading = true;
                    continue; // Skip the label itself
                }
            }

            return content.Trim();
        }

        private bool IsLabel(string text)
        {
            // Define labels that indicate the end of the relevant content
            string[] labels = { "Technical checklist:", "END OF DOCUMENT" };

            // Check if the text matches any of the labels
            foreach (string label in labels)
            {
                if (text.ToLower().StartsWith(label.ToLower()))
                {
                    return true;
                }
            }

            return false;
        }
        */
        public void GetExternalChecklist(List<string> issueIds)
        {
            

            string folderPath = DirectoryPath.DownloadSD;
            Application wordApp = new Application();

            foreach (string issueId in issueIds)
            {
                string filePath = Path.Combine(folderPath, issueId);

                if (File.Exists(filePath + ".docx"))
                    filePath += ".docx";
                else if (File.Exists(filePath + ".doc"))
                    filePath += ".doc";
                else
                {
                    checklist[issueId] = "Summary not available";
                    continue;
                }

                try
                {
                    Document doc = wordApp.Documents.Open(filePath);
                    string fileContents = ReadContentAfterIssueSummary(doc);
                    doc.Close(WdSaveOptions.wdDoNotSaveChanges);
                    checklist[issueId] = fileContents;
                }
                catch (Exception ex)
                {
                    checklist[issueId] = $"Error: {ex.Message}";
                }
            }

            wordApp.Quit();
            foreach (var kvp in checklist)
            {
                //message += $"Issue ID: {kvp.Key},{kvp.Value}\n";
            }
        }

        private string ReadContentAfterIssueSummary(Document doc)
        {
            string content = "";
            bool startReading = false;

            foreach (Paragraph para in doc.Paragraphs)
            {
                string text = para.Range.Text.Trim();

                if (startReading)
                {
                    if (IsLabel(text))
                    {
                        break;
                    }

                    content += text + "\n";
                }

                if (text.ToLower().StartsWith("external checklist:"))
                {
                    int index = text.IndexOf("EXTERNAL CHECKLIST:") + "EXTERNAL CHECKLIST:".Length;
                    content += text.Substring(index).Trim() + "\n";
                    startReading = true;
                }
            }

            return content.Trim();
        }

        private bool IsLabel(string text)
        {
            string[] labels = { "Technical checklist:", "END OF DOCUMENT", "EXTERNAL CHECKLIST:", "DEPENDENCIES:" };

            foreach (string label in labels)
            {
                if (text.ToLower().StartsWith(label.ToLower()))
                {
                    return true;
                }
            }

            return false;
        }



        /*public void AddExternalChecklist(Dictionary<string, string> checklist)
        {
            string excelFolderPath = DirectoryPath.proximafiledirectory; // Specify the path to the folder containing Excel files

            // Get all Excel files in the directory
            string[] excelFiles = Directory.GetFiles(excelFolderPath, "*.xlsx");

            // Sort the files based on creation time in descending order
            Array.Sort(excelFiles, (a, b) => new FileInfo(b).CreationTime.CompareTo(new FileInfo(a).CreationTime));

            // Select the most recent Excel file
            string excelFilePath = excelFiles.FirstOrDefault();

            if (excelFilePath == null)
            {
                Console.WriteLine("No Excel files found in the directory.");
                return;
            }

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workbook = excelApp.Workbooks.Open(excelFilePath);
            Excel.Worksheet worksheet = workbook.Sheets["Combined Data"]; // Assuming the data is in the first sheet

            try
            {
                //int row = 2; // Start from the second row (assuming the first row is header)
                foreach (var kvp in checklist)
                {
                    string issueId = kvp.Key;
                    string externalText = kvp.Value;

                    // Find the row with the corresponding issue ID in the first column
                    Excel.Range cell = worksheet.Range["A:A"].Find(issueId);
                    if (cell != null)
                    {
                        // Update the value in the "External Text" column (assuming it's in the second column)
                        worksheet.Cells[cell.Row, 5].Value = externalText;
                    }
                    else
                    {
                        Console.WriteLine($"Issue ID '{issueId}' not found in the Excel file.");
                    }
                }

                // Save and close the workbook
                workbook.Save();
                workbook.Close();
            }
            finally
            {
                // Close Excel application
                excelApp.Quit();
                ReleaseObject(worksheet);
                ReleaseObject(workbook);
                ReleaseObject(excelApp);
            }
        }*/

        /*
        public void AddExternalChecklist(Dictionary<string, string> checklist, Dictionary<string, string> instruction)
        {
            string excelFolderPath = DirectoryPath.proximafiledirectory; // Specify the path to the folder containing Excel files

            // Get all Excel files in the directory
            string[] excelFiles = Directory.GetFiles(excelFolderPath, "*.xlsx");

            // Sort the files based on creation time in descending order
            Array.Sort(excelFiles, (a, b) => new FileInfo(b).CreationTime.CompareTo(new FileInfo(a).CreationTime));

            // Select the most recent Excel file
            string excelFilePath = excelFiles.FirstOrDefault();

            if (excelFilePath == null)
            {
                Console.WriteLine("No Excel files found in the directory.");
                return;
            }

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workbook = excelApp.Workbooks.Open(excelFilePath);
            Excel.Worksheet worksheet = workbook.Sheets["Combined Data"]; // Assuming the data is in the first sheet

            try
            {
                foreach (var kvp in checklist)
                {
                    string issueId = kvp.Key;
                    string externalText = kvp.Value;

                    // Remove \r, \n, and \a characters and trim whitespace
                    string normalizedExternalText = externalText.Replace("\r", "").Replace("\n", "").Replace("\a", "").Trim();

                    // Check if the external text is "NA" or null in the checklist dictionary
                    if (string.IsNullOrEmpty(normalizedExternalText) || normalizedExternalText.Equals("NA", StringComparison.OrdinalIgnoreCase))
                    {
                        // Check if there's a corresponding value in the instruction dictionary
                        if (instruction.TryGetValue(issueId, out string instructionValue))
                        {
                            // Update the value in the fifth column with the instruction value
                            UpdateWorksheet(issueId, instructionValue, worksheet);
                        }
                        else
                        {
                            // If the instruction for the issueId is not found, carry the value from the checklist dictionary
                            if (checklist.TryGetValue(issueId, out string checklistValue))
                            {
                                // Update the value in the fifth column with the value from the checklist dictionary
                                UpdateWorksheet(issueId, checklistValue, worksheet);
                            }
                            else
                            {
                                Console.WriteLine($"Issue ID '{issueId}' not found in the Excel file or the instruction dictionary.");
                            }
                        }
                    }
                }

                // Save and close the workbook
                workbook.Save();
                workbook.Close();
            }
            finally
            {
                // Close Excel application
                excelApp.Quit();
                ReleaseObject(worksheet);
                ReleaseObject(workbook);
                ReleaseObject(excelApp);
            }
        }


        private void UpdateWorksheet(string issueId, string value, Excel.Worksheet worksheet)
        {
            // Find the row with the corresponding issue ID in the first column
            Excel.Range cell = worksheet.Range["A:A"].Find(issueId);
            if (cell != null)
            {
                // Update the value in the fifth column with the provided value
                worksheet.Cells[cell.Row, 5].Value = value;
            }
            else
            {
                Console.WriteLine($"Issue ID '{issueId}' not found in the Excel file.");
            }
        }*/


        public void AddExternalChecklist(Dictionary<string, string> checklist, Dictionary<string, string> instruction)
        {
            // Create a copy of the checklist
            Dictionary<string, string> checklistCopy = new Dictionary<string, string>(checklist);

            // Iterate through the checklist copy
            foreach (var kvp in checklistCopy)
            {
                string issueId = kvp.Key;
                string externalText = kvp.Value;

                // Normalize the external text by removing \r, \n, and \a characters and trimming whitespace
                string normalizedExternalText = externalText?.Replace("\r", "").Replace("\n", "").Replace("\a", "").Trim();

                // Check if the normalized external text is null, empty, or "NA" (case-insensitive)
                if (string.IsNullOrEmpty(normalizedExternalText) || normalizedExternalText.Equals("NA", StringComparison.OrdinalIgnoreCase))
                {
                    // Check if there's a corresponding value in the instruction dictionary
                    if (instruction.TryGetValue(issueId, out string instructionValue))
                    {
                        // Update the value in the original checklist with the instruction value
                        checklist[issueId] = instructionValue;
                    }
                }
            }

            // Proceed with updating the Excel worksheet using the modified checklist
            string excelFolderPath = DirectoryPath.proximafiledirectory; // Specify the path to the folder containing Excel files

            // Get all Excel files in the directory
            string[] excelFiles = Directory.GetFiles(excelFolderPath, "*.xlsx");

            // Sort the files based on creation time in descending order
            Array.Sort(excelFiles, (a, b) => new FileInfo(b).CreationTime.CompareTo(new FileInfo(a).CreationTime));

            // Select the most recent Excel file
            string excelFilePath = excelFiles.FirstOrDefault();

            if (excelFilePath == null)
            {
                Console.WriteLine("No Excel files found in the directory.");
                return;
            }

            Excel.Application excelApp = new Excel.Application();
            Excel.Workbook workbook = excelApp.Workbooks.Open(excelFilePath);
            Excel.Worksheet worksheet = workbook.Sheets["Combined Data"]; // Assuming the data is in the first sheet

            try
            {
                // Iterate through the modified checklist to update the Excel worksheet
                foreach (var kvp in checklist)
                {
                    string issueId = kvp.Key;
                    string externalText = kvp.Value;

                    // Find the row with the corresponding issue ID in the first column
                    Excel.Range cell = worksheet.Range["A:A"].Find(issueId);
                    if (cell != null)
                    {
                        // Update the value in the fifth column with the external text
                        worksheet.Cells[cell.Row, 5].Value = externalText;
                    }
                    else
                    {
                        Console.WriteLine($"Issue ID '{issueId}' not found in the Excel file.");
                    }
                }
                CleanUpWorksheet(worksheet);
                // Save and close the workbook
                workbook.Save();
                workbook.Close();
            }
            finally
            {
                // Close Excel application
                excelApp.Quit();
                //DirectoryPath.CloseAllReadOnlyWorkbooks();
                ReleaseObject(worksheet);
                ReleaseObject(workbook);
                ReleaseObject(excelApp);
            }
        }


        // Method to release COM objects to avoid memory leaks
        private void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error releasing COM object: {ex.Message}");
            }
            finally
            {
                GC.Collect();
            }
        }

        public void GetSpecialInstructions(List<string> issueIds)
        {
            string folderPath = DirectoryPath.DownloadSD;
            Application wordApp = new Application();

            try
            {
                foreach (string issueId in issueIds)
                {
                    string filePath = Path.Combine(folderPath, issueId);

                    if (File.Exists(filePath + ".docx"))
                        filePath += ".docx";
                    else if (File.Exists(filePath + ".doc"))
                        filePath += ".doc";
                    else
                    {
                        instructions[issueId] = "Summary not available";
                        continue;
                    }

                    try
                    {
                        Document doc = wordApp.Documents.Open(filePath);
                        string fileContents = ReadSpecialInstructions(doc);
                        doc.Close(WdSaveOptions.wdDoNotSaveChanges);
                        instructions[issueId] = fileContents;
                    }
                    catch (Exception ex)
                    {
                        instructions[issueId] = $"Error: {ex.Message}";
                    }
                }
            }
            finally
            {
                wordApp.Quit();
            }

            // Add the instructions to your data structure or perform further processing
            foreach (var kvp in instructions)
            {
                // Do something with the instructions
            }
        }

        private string ReadSpecialInstructions(Document doc)
        {
            string content = "";
            bool startReading = false;

            foreach (Paragraph para in doc.Paragraphs)
            {
                string text = para.Range.Text.Trim();

                if (startReading)
                {
                    if (CheckLabel(text))
                    {
                        break;
                    }

                    content += text + "\n";
                }

                if (text.ToLower().StartsWith("special instructions:"))
                {
                    int index = text.IndexOf("SPECIAL INSTRUCTIONS: ") + "SPECIAL INSTRUCTIONS: ".Length;
                    content += text.Substring(index).Trim() + "\n";
                    startReading = true;
                }
            }

            return content.Trim();
        }

        private bool CheckLabel(string text)
        {
            string[] labels = { "EXTERNAL CHECKLIST:", "DEPENDENCIES:" };

            foreach (string label in labels)
            {
                if (text.ToLower().StartsWith(label.ToLower()))
                {
                    return true;
                }
            }
            return false;
        }

        public void CleanUpWorksheet(Excel.Worksheet worksheet)
        {
            // Get the used range of the worksheet
            Excel.Range usedRange = worksheet.UsedRange;

            // Iterate through each cell in the used range
            foreach (Excel.Range cell in usedRange)
            {
                // Remove leading and trailing spaces and unwanted symbols from the cell's value
                string cellValue = cell.Value?.ToString().Trim();
                if (!string.IsNullOrEmpty(cellValue))
                {
                    cell.Value = RemoveUnwantedSymbols(cellValue);
                }
            }
        }

        // Method to remove unwanted symbols from a string
        private string RemoveUnwantedSymbols(string input)
        {
            // Define unwanted symbols to remove
            char[] unwantedSymbols = { '\r', '\n', '\a' };

            // Remove unwanted symbols from the input string
            foreach (char symbol in unwantedSymbols)
            {
                input = input.Replace(symbol.ToString(), "");
            }

            return input.Trim();
        }



        /*public void CopyCombinedDataToNewWorkbook()
        {
            try
            {
                // Set the source folder path (hardcoded)
                string sourceFolderPath = DirectoryPath.proximafiledirectory;

                // Get all Excel files in the source directory
                DirectoryInfo dirInfo = new DirectoryInfo(sourceFolderPath);
                FileInfo[] files = dirInfo.GetFiles("*.xlsx");

                // Sort the files based on creation time in descending order
                Array.Sort(files, (a, b) => b.CreationTime.CompareTo(a.CreationTime));

                // Pick the most recent Excel file
                string sourceFilePath = files.FirstOrDefault()?.FullName;

                if (sourceFilePath == null)
                {
                    Console.WriteLine("No Excel files found in the source directory.");
                    return;
                }

                // Set the destination folder path (hardcoded)
                string destinationFolderPath = DirectoryPath.finalbulletins;

                // Get the current date
                DateTime currentDate = DateTime.Now;

                // Construct the destination file name with the format "Service Bulletin DD MMM - DD MMM YYYY.xlsx"
                string destinationFileName = string.Format("Service Bulletin {0:dd MMM} - {1:dd MMM yyyy}.xlsx", currentDate.AddDays(-7), currentDate);

                // Combine the destination folder path and file name to get the full destination path
                string destinationFilePath = Path.Combine(destinationFolderPath, destinationFileName);

                // Create a new Excel application
                Excel.Application excelApp = new Excel.Application();
                excelApp.DisplayAlerts = false;

                // Open the source workbook
                Excel.Workbook sourceWorkbook = excelApp.Workbooks.Open(sourceFilePath);

                // Find the "Combined Data" sheet in the source workbook
                Excel.Worksheet sourceSheet = null;
                foreach (Excel.Worksheet sheet in sourceWorkbook.Sheets)
                {
                    if (sheet.Name == "Combined Data")
                    {
                        sourceSheet = sheet;
                        break;
                    }
                }

                if (sourceSheet != null)
                {
                    // Add a new workbook for the destination
                    Excel.Workbook newWorkbook = excelApp.Workbooks.Add();

                    // Create a new worksheet in the new workbook
                    Excel.Worksheet destinationSheet = newWorkbook.Sheets[1];

                    // Rename the new worksheet to "e-Emphasys Solution"
                    destinationSheet.Name = "e-Emphasys Solution";

                    // Copy data and formatting cell by cell from the source sheet to the destination sheet
                    sourceSheet.Cells.Copy(destinationSheet.Cells);

                    // Save the new workbook to the destination path
                    newWorkbook.SaveAs(destinationFilePath);

                    // Mark the workbook as saved with the specified name
                    newWorkbook.Saved = true;

                    // Close the new workbook
                    newWorkbook.Close(false);
                }
                else
                {
                    Console.WriteLine("The 'Combined Data' sheet was not found in the source workbook.");
                }

                // Close the source workbook
                sourceWorkbook.Close(false);
                //DirectoryPath.CloseAllReadOnlyWorkbooks();

                // Close the Excel application
                excelApp.Quit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occurred: " + ex.Message);
            }
        }
        */

        public void CopyCombinedDataToNewWorkbook()
        {
            try
            {
                // Set the source folder path (hardcoded)
                string sourceFolderPath = DirectoryPath.proximafiledirectory;

                // Get all Excel files in the source directory
                DirectoryInfo dirInfo = new DirectoryInfo(sourceFolderPath);
                FileInfo[] files = dirInfo.GetFiles("*.xlsx");

                // Sort the files based on creation time in descending order
                Array.Sort(files, (a, b) => b.CreationTime.CompareTo(a.CreationTime));

                // Pick the most recent Excel file
                string sourceFilePath = files.FirstOrDefault()?.FullName;

                if (sourceFilePath == null)
                {
                    Console.WriteLine("No Excel files found in the source directory.");
                    return;
                }

                // Set the destination folder path (hardcoded)
                string destinationFolderPath = DirectoryPath.finalbulletins;

                // Get the current date
                DateTime currentDate = DateTime.Now;

                // Construct the destination file name with the format "Service Bulletin DD MMM - DD MMM YYYY.xlsx"
                string destinationFileName = string.Format("Service Bulletin {0:dd MMM} - {1:dd MMM yyyy}.xlsx", currentDate.AddDays(-7), currentDate);

                // Combine the destination folder path and file name to get the full destination path
                string destinationFilePath = Path.Combine(destinationFolderPath, destinationFileName);

                // Create a new Excel application
                Excel.Application excelApp = new Excel.Application();
                excelApp.DisplayAlerts = false;

                // Open the source workbook
                Excel.Workbook sourceWorkbook = excelApp.Workbooks.Open(sourceFilePath);

                // Find the "Combined Data" sheet in the source workbook
                Excel.Worksheet sourceSheet = null;
                foreach (Excel.Worksheet sheet in sourceWorkbook.Sheets)
                {
                    if (sheet.Name == "Combined Data")
                    {
                        sourceSheet = sheet;
                        break;
                    }
                }

                if (sourceSheet != null)
                {
                    // Add a new workbook for the destination
                    Excel.Workbook newWorkbook = excelApp.Workbooks.Add();

                    // Create a new worksheet in the new workbook
                    Excel.Worksheet destinationSheet = newWorkbook.Sheets[1];

                    // Rename the new worksheet to "e-Emphasys Solution"
                    destinationSheet.Name = "e-Emphasys Solution";

                    // Copy data from specific columns A to G from the source sheet to the destination sheet
                    Excel.Range sourceRange = sourceSheet.Range["A:G"];
                    Excel.Range destinationRange = destinationSheet.Range["A1:G" + sourceSheet.Cells.Rows.Count];
                    sourceRange.Copy(destinationRange);

                    // Set column widths in the destination sheet
                    destinationSheet.Columns["A"].ColumnWidth = 12.33;
                    destinationSheet.Columns["B"].ColumnWidth = 10.22;
                    destinationSheet.Columns["C"].ColumnWidth = 75.11;
                    destinationSheet.Columns["D"].ColumnWidth = 9.67;
                    destinationSheet.Columns["E"].ColumnWidth = 75.22;
                    destinationSheet.Columns["F"].ColumnWidth = 67.78;
                    destinationSheet.Columns["G"].ColumnWidth = 16.67;

                    // Save the new workbook to the destination path
                    newWorkbook.SaveAs(destinationFilePath);

                    // Mark the workbook as saved with the specified name
                    newWorkbook.Saved = true;

                    // Close the new workbook
                    newWorkbook.Close(false);
                }
                else
                {
                    Console.WriteLine("The 'Combined Data' sheet was not found in the source workbook.");
                }

                // Close the source workbook
                sourceWorkbook.Close(false);
                //DirectoryPath.CloseAllReadOnlyWorkbooks();

                // Close the Excel application
                excelApp.Quit();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error occurred: " + ex.Message);
            }
        }



    }
}