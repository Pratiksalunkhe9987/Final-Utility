﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAddInbulletins
{
    internal class getSheet3
    {
        //changes done here
        List<string> existIds = new List<string>();
        List<string> filterIds = new List<string>();
        Dictionary<string, string> summary = new Dictionary<string, string>();
        /* public void CopyDataToFinal_SD_Download_List()
         {
             Excel.Workbook workbook = Globals.ThisAddIn.Application.ActiveWorkbook;

             if (workbook == null)
             {
                 MessageBox.Show("No active workbook found.");
                 return;
             }

             Excel.Worksheet sourceWorksheet = workbook.Sheets["Check Underscore & SD download"];
             Excel.Worksheet underscoreSDWorksheet = null;

             // Check if the underscoreSDWorksheet exists, if not, add it
             try
             {
                 underscoreSDWorksheet = workbook.Sheets["Final SD Download List"];
             }
             catch
             {
                 // underscoreSDWorksheet doesn't exist, so add it
                 underscoreSDWorksheet = (Excel.Worksheet)workbook.Sheets.Add();
                 underscoreSDWorksheet.Name = "Final SD Download List";
             }

             if (sourceWorksheet == null)
             {
                 MessageBox.Show("Source worksheet not found.");
                 return;
             }

             // Define the columns you want to copy (e.g., columns A, B, C)
             int[] columnsToCopy = { 1, 2, 3, 4, 5, 6, 7, 8 }; // Column indices are 1-based

             Excel.Range sourceRange = sourceWorksheet.UsedRange;
             Excel.Range destinationRange = underscoreSDWorksheet.Cells[1, 1];

             int destinationRow = 1;

             foreach (Excel.Range sourceRow in sourceRange.Rows)
             {
                 // Check if the row is marked in red
                 if (IsRowMarkedRed(sourceRow))
                 {
                     // Skip copying this row
                     continue;
                 }

                 // Copy data from the specified columns in the source row to the destination row
                 foreach (int column in columnsToCopy)
                 {
                     Excel.Range sourceCell = (Excel.Range)sourceRow.Cells[1, column];
                     Excel.Range destinationCell = (Excel.Range)destinationRange.Cells[destinationRow, column];

                     destinationCell.Value = sourceCell.Value;

                     sourceCell.Copy();
                     destinationCell.PasteSpecial(Excel.XlPasteType.xlPasteFormats);
                     destinationCell.PasteSpecial(Excel.XlPasteType.xlPasteColumnWidths);
                     underscoreSDWorksheet.Application.CutCopyMode = Excel.XlCutCopyMode.xlCopy;
                 }

                 destinationRow++;
             }

             Excel.Range allCells = underscoreSDWorksheet.Cells;
             Excel.Borders borders = allCells.Borders;
             borders.LineStyle = Excel.XlLineStyle.xlContinuous;
             borders.Weight = Excel.XlBorderWeight.xlThin;

             MessageBox.Show("Data copied from Source to 'Check Underscore & SD download' sheet.");
         }
          // Helper method to check if a row is marked in red
          private bool IsRowMarkedRed(Excel.Range row)
          {
              return row.Interior.Color == System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Red);
          }*/
        public void CopyHeaderToFinal_SD_Download_List(List<string> existIds)
        {
            Excel.Workbook workbook = Globals.ThisAddIn.Application.ActiveWorkbook;

            if (workbook == null)
            {
                MessageBox.Show("No active workbook found.");
                return;
            }

            Excel.Worksheet sourceWorksheet = workbook.Sheets["Check Underscore & SD download"];
            Excel.Worksheet underscoreSDWorksheet = null;

            // Check if the underscoreSDWorksheet exists, if not, add it
            try
            {
                underscoreSDWorksheet = workbook.Sheets["Final SD Download List"];
            }
            catch
            {
                // underscoreSDWorksheet doesn't exist, so add it
                underscoreSDWorksheet = (Excel.Worksheet)workbook.Sheets.Add();
                underscoreSDWorksheet.Name = "Final SD Download List";
            }

            if (sourceWorksheet == null)
            {
                MessageBox.Show("Source worksheet not found.");
                return;
            }

            // Get the used range of the source worksheet
            Excel.Range sourceRange = sourceWorksheet.Rows[1]; // Only copy the first row (column headers)

            // Get the destination range (first row) in the destination worksheet
            Excel.Range destinationRange = underscoreSDWorksheet.Rows[1];

            // Copy the column headers from the source to the destination
            sourceRange.Copy(destinationRange);

            // Clear clipboard
            Clipboard.Clear();

            MessageBox.Show("Column headers copied from 'Check Underscore & SD download' sheet to 'Final SD Download List' sheet.");

            //DirectoryPath.CloseAllReadOnlyWorkbooks();
//changes don heare 

            Addissueids ob1 = new Addissueids();
            filterIds = ob1.FilterExistingIds(existIds);
            ob1.AddIds(filterIds);

            FileZillaClient obj = new FileZillaClient();
            foreach (string id in existIds)
            {
                obj.Download(id);
                //obj.Downloadvariant(id);
            }
            MessageBox.Show("SD downloaded successfully");
            //will change the name of the file from downloaded folder
            ob1.RenameFilesInFolder();
            //get summary from the file 
            getsummaryfromfile read = new getsummaryfromfile();
            summary = read.GetSummary(filterIds);


            //copy the other column data from check underscore and sd download sheet  to final sd download sheet 
            ob1.CopyDataToFinal_SD_Download_List(summary);
            
            underscoreSDWorksheet.Columns["A"].ColumnWidth = 11.44;
            underscoreSDWorksheet.Columns["B"].ColumnWidth = 8.78;
            underscoreSDWorksheet.Columns["C"].ColumnWidth = 107.56;
            underscoreSDWorksheet.Columns["D"].ColumnWidth = 10.78;
            underscoreSDWorksheet.Columns["E"].ColumnWidth = 16.67;
            underscoreSDWorksheet.Columns["F"].ColumnWidth = 16;
            underscoreSDWorksheet.Columns["G"].ColumnWidth = 15.56;
            underscoreSDWorksheet.Columns["H"].ColumnWidth = 7.33;

            AutofitRowHeights(underscoreSDWorksheet);

            Readchecklist oj = new Readchecklist();
            oj.CleanUpWorksheet(underscoreSDWorksheet);
            markabsentsummary(underscoreSDWorksheet);
            underscoreSDWorksheet.Activate();

        }

        private void AutofitRowHeights(Excel.Worksheet worksheet)
        {
            Excel.Range usedRange = worksheet.UsedRange;
            Excel.Range rows = usedRange.Rows;

            foreach (Excel.Range row in rows)
            {
                row.EntireRow.AutoFit();
            }
        }

        private void markabsentsummary(Excel.Worksheet worksheet)
        {
            Excel.Range usedRange = worksheet.UsedRange;

            foreach (Excel.Range row in usedRange.Rows)
            {
                // Get the summary value for the current row
                string summaryValue = worksheet.Cells[row.Row, 3].Value?.ToString(); // Assuming summary is in column C
                string columnEValue = worksheet.Cells[row.Row, 5].Value?.ToString(); // Assuming column E contains "Not specified"

                // Check if the summary value contains the error message, or if it's blank or null,
                // or if column E contains "Not specified"
                if (string.IsNullOrWhiteSpace(summaryValue) || summaryValue.Contains("Error: Word cannot open the file because the file format does not match the file extension.")
                    || columnEValue.Contains("Not Specified"))
                {
                    // Mark the entire row in yellow
                    row.Interior.Color = System.Drawing.Color.Yellow;
                }
            }
        }
    }
}
