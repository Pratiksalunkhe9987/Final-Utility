﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelAddInbulletins
{
    public class IssueIdComparer : IComparer<string>
    {
        public int Compare(string x, string y)
        {
            string[] partsX = x.Split('_');
            string[] partsY = y.Split('_');

            int mainX = int.Parse(partsX[0]);
            int mainY = int.Parse(partsY[0]);

            if (mainX != mainY)
            {
                return mainX.CompareTo(mainY);
            }

            if (partsX.Length > 1 && partsY.Length > 1)
            {
                // Parse the optional number part if it exists
                int numX, numY;
                if (int.TryParse(partsX[1], out numX) && int.TryParse(partsY[1], out numY))
                {
                    return numX.CompareTo(numY);
                }
            }

            // Default to comparing the full issue IDs if the optional number part is not available or invalid
            return x.CompareTo(y);
        }
    }

}
