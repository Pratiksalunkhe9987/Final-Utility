﻿using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using Application = Microsoft.Office.Interop.Excel.Application;
using Range = Microsoft.Office.Interop.Excel.Range;

namespace ExcelAddInbulletins
{
    internal class addchecklist
    {
        List<string> list = new List<string>();

        public void AddChecklistsIfBlank()
        {
            string excelFolderPath = DirectoryPath.proximafiledirectory; // Specify the path to your Excel folder

            // Check if the folder exists
            if (!Directory.Exists(excelFolderPath))
            {
                Console.WriteLine($"Excel folder not found at {excelFolderPath}.");
                return;
            }

            Dictionary<string, Tuple<string, string>> checklistDictionary = new Dictionary<string, Tuple<string, string>>();

            try
            {
                // Get all Excel files in the directory
                string[] excelFiles = Directory.GetFiles(excelFolderPath, "*.xlsx");

                // Sort the files based on creation time in descending order
                Array.Sort(excelFiles, (a, b) => new FileInfo(b).CreationTime.CompareTo(new FileInfo(a).CreationTime));

                if (excelFiles.Length > 0)
                {
                    // Open the most recent Excel file
                    Application excelApp = new Application();
                    excelApp.Visible = true;
                    Workbook workbook = excelApp.Workbooks.Open(excelFiles[0]);

                    // Get the "Combined Data" worksheet
                    Worksheet worksheet = workbook.Sheets["Combined Data"] as Worksheet;
                    if (worksheet == null)
                    {
                        Console.WriteLine("Sheet 'Combined Data' not found in the Excel file.");
                        workbook.Close(false);
                        excelApp.Quit();
                        return;
                    }

                    // Define column indices for IssueID, External text, and Internal text
                    int issueIdColumnIndex = 1; // Assuming IssueID is in the first column (Column A)
                    int externalTextColumnIndex = 5; // Example: Column B
                    int internalTextColumnIndex = 6; // Example: Column C

                    Range dataRange = worksheet.UsedRange;

                    string currentIssueId = null;
                    string currentExternalText = null;
                    string currentInternalText = null;

                    for (int i = 2; i <= dataRange.Rows.Count; i++) // Start iterating from the second row
                    {
                        Range row = (Range)dataRange.Rows[i];
                        // Get values from cells
                        string issueId = row.Cells[1, issueIdColumnIndex]?.Value?.ToString();
                        string externalText = row.Cells[1, externalTextColumnIndex]?.Value?.ToString();
                        string internalText = row.Cells[1, internalTextColumnIndex]?.Value?.ToString();

                        // Check if the issueId is not null
                        if (!string.IsNullOrEmpty(issueId))
                        {
                            // If there is a change in issue ID, add the previous data to the dictionary
                            if (currentIssueId != null && currentIssueId != issueId)
                            {
                                checklistDictionary.Add(currentIssueId, Tuple.Create(currentExternalText, currentInternalText));
                                currentExternalText = null; // Reset the currentExternalText for the new issueId
                                currentInternalText = null; // Reset the currentInternalText for the new issueId
                            }

                            currentIssueId = issueId; // Update the current issue ID
                        }

                        // Concatenate external text if it spans multiple rows
                        if (!string.IsNullOrEmpty(externalText))
                        {
                            currentExternalText = currentExternalText != null ? $"{currentExternalText}\n{externalText}" : externalText;
                        }

                        // Concatenate internal text if it spans multiple rows
                        if (!string.IsNullOrEmpty(internalText))
                        {
                            currentInternalText = currentInternalText != null ? $"{currentInternalText}\n{internalText}" : internalText;
                        }
                    }

                    // Add the last issueId and its texts to the dictionary
                    if (currentIssueId != null)
                    {
                        checklistDictionary.Add(currentIssueId, Tuple.Create(currentExternalText, currentInternalText));
                    }

                    // Close the workbook and quit Excel application
                    workbook.Close(false);
                    excelApp.Quit();

                    // Print the checklist data from the dictionary
                    
                }
                else
                {
                    // No Excel files found in the directory
                    Console.WriteLine("No Excel files found in the directory.");
                }
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                Console.WriteLine($"Error: {ex.Message}");
            }
            Readchecklist obj = new Readchecklist();
            obj.UpdateChecklistExternalText(checklistDictionary);
            //obj.GetExternalChecklistSummary(list);
            foreach (var kvp in checklistDictionary)
            {
                string issueId = kvp.Key;
                string externalText = kvp.Value.Item1;
                string internalText = kvp.Value.Item2;

                Console.WriteLine($"Issue ID: {issueId}");
                Console.WriteLine($"External Text: {externalText}");
                Console.WriteLine($"Internal Text: {internalText}");
                Console.WriteLine();
            }
            //DirectoryPath.CloseAllReadOnlyWorkbooks();
        }


    }
}
