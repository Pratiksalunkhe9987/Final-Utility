﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Application = Microsoft.Office.Interop.Word.Application;
using Microsoft.Office.Interop.Excel;
using Range = Microsoft.Office.Interop.Excel.Range;
using System.Runtime.InteropServices;


namespace ExcelAddInbulletins
{
    internal class getsummaryfromfile
    {
        Dictionary<string, string> summary = new Dictionary<string, string>();
        /* public Dictionary<string, string> GetSummary(List<string> existIds)
         {
             // Assuming the folder path where the summary files are stored
             string folderPath = @"C:\Users\psalunkhe\Desktop\Macro\download";

             // Create an instance of the Word application
             Application wordApp = new Application();

             // Variable to store the message to display in the message box
             string message = "Summary Data:\n";

             foreach (string existId in existIds)
             {
                 // Generate the file path based on the existId
                 string filePath = Path.Combine(folderPath, existId);

                 // Check if the file exists with .docx extension
                 if (File.Exists(filePath + ".docx"))
                 {
                     filePath += ".docx";
                 }
                 else if (File.Exists(filePath + ".doc")) // Check if the file exists with .doc extension
                 {
                     filePath += ".doc";
                 }
                 else
                 {
                     // Handle case where file does not exist for the existId
                     // For example, set a default summary or skip this existId
                     summary[existId] = "Summary not available";
                     continue;
                 }

                 // Open the Word document
                 Document doc = wordApp.Documents.Open(filePath);

                 // Read the content after the "ISSUE SUMMARY:" section
                 string fileContents = ReadContentAfterIssueSummary(doc);

                 // Close the document without saving changes
                 doc.Close(WdSaveOptions.wdDoNotSaveChanges);

                 // Add the summary to the dictionary with the existId as the key
                 summary[existId] = fileContents;

                 // Add the summary to the message to display in the message box
                 message += $"Issue ID: {existId},{fileContents}\n";
             }

             // Quit the Word application
             wordApp.Quit();

             // Display the message box with the summary data
             MessageBox.Show(message, "Summary Data", MessageBoxButtons.OK, MessageBoxIcon.Information);

             return summary;
         }

         // Function to read the content after the "ISSUE SUMMARY:" section
         private string ReadContentAfterIssueSummary(Document doc)
         {
             // Initialize the content variable
             string content = "";

             // Find the paragraph containing "ISSUE SUMMARY:"
             foreach (Paragraph para in doc.Paragraphs)
             {
                 if (para.Range.Text.Contains("ISSUE SUMMARY:"))
                 {
                     // Get the index of the "ISSUE SUMMARY:" paragraph
                     int index = para.Range.Text.IndexOf("ISSUE SUMMARY:") + "ISSUE SUMMARY:".Length;

                     // Read the content after "ISSUE SUMMARY:"
                     content = para.Range.Text.Substring(index).Trim();

                     // Break the loop after finding the "ISSUE SUMMARY:" paragraph
                     break;
                 }
             }

             return content;
         }*/


        // Function to read the content after the "ISSUE SUMMARY:" section
        /*public Dictionary<string, string> GetSummary(List<string> existIds)
        {
            Dictionary<string, string> summary = new Dictionary<string, string>();

            string folderPath = @"C:\Users\psalunkhe\Desktop\Macro\download";
            Application wordApp = new Application();

            foreach (string existId in existIds)
            {
                string filePath = Path.Combine(folderPath, existId);

                if (File.Exists(filePath + ".docx"))
                    filePath += ".docx";
                else if (File.Exists(filePath + ".doc"))
                    filePath += ".doc";
                else
                {
                    summary[existId] = "Summary not available";
                    continue;
                }

                try
                {
                    Document doc = wordApp.Documents.Open(filePath);
                    string fileContents = ReadContentAfterIssueSummary(doc);
                    doc.Close(WdSaveOptions.wdDoNotSaveChanges);
                    summary[existId] = fileContents;
                }
                catch (Exception ex)
                {
                    summary[existId] = $"Error: {ex.Message}";
                }
            }

            wordApp.Quit();

            string message = "Summary Data:\n";
            foreach (var kvp in summary)
            {
                message += $"Issue ID: {kvp.Key},{kvp.Value}\n";
            }

            MessageBox.Show(message, "Summary Data", MessageBoxButtons.OK, MessageBoxIcon.Information);

            return summary;
        }

        private string ReadContentAfterIssueSummary(Document doc)
        {
            string content = "";
            foreach (Paragraph para in doc.Paragraphs)
            {
                if (para.Range.Text.Trim().ToLower().StartsWith("issue summary:"))
                {
                    int index = para.Range.Text.IndexOf("ISSUE SUMMARY:") + "ISSUE SUMMARY:".Length;
                    content = para.Range.Text.Substring(index).Trim();
                    break;
                }
            }
            return content;
        }*/

        public Dictionary<string, string> GetSummary(List<string> existIds)
        {
            Dictionary<string, string> summary = new Dictionary<string, string>();

            string folderPath = DirectoryPath.DownloadSD;
            Application wordApp = new Application();

            foreach (string existId in existIds)
            {
                string filePath = Path.Combine(folderPath, existId);

                if (File.Exists(filePath + ".docx"))
                    filePath += ".docx";
                else if (File.Exists(filePath + ".doc"))
                    filePath += ".doc";
                else
                {
                    summary[existId] = "Summary not available";
                    continue;
                }

                try
                {
                    Document doc = wordApp.Documents.Open(filePath);
                    string fileContents = ReadContentAfterIssueSummary(doc);
                    doc.Close(WdSaveOptions.wdDoNotSaveChanges);
                    summary[existId] = fileContents;
                }
                catch (Exception ex)
                {
                    summary[existId] = $"Error: {ex.Message}";
                }
            }

            wordApp.Quit();
            //DirectoryPath.CloseAllReadOnlyWorkbooks();
            /* string message = "Summary Data:\n";
              foreach (var kvp in summary)
              {
                  message += $"Issue ID: {kvp.Key},{kvp.Value}\n";
              }

              MessageBox.Show(message, "Summary Data", MessageBoxButtons.OK, MessageBoxIcon.Information);
            */
            MessageBox.Show("summary reading from the file");
            return summary;
        }

        private string ReadContentAfterIssueSummary(Document doc)
        {
            string content = "";
            bool startReading = false;

            foreach (Paragraph para in doc.Paragraphs)
            {
                string text = para.Range.Text.Trim();

                if (startReading)
                {
                    if (IsLabel(text))
                    {
                        break;
                    }

                    content += text + "\n";
                }

                if (text.ToLower().StartsWith("issue summary:"))
                {
                    int index = text.IndexOf("ISSUE SUMMARY:") + "ISSUE SUMMARY:".Length;
                    content += text.Substring(index).Trim() + "\n";
                    startReading = true;
                }
            }

            return content.Trim();
        }

        private bool IsLabel(string text)
        {
            string[] labels = { "HELP DESK ID:", "VERSION(S):", "SITUATION IDENTIFIED IN:", "SITUATION DESCRIPTION:" };

            foreach (string label in labels)
            {
                if (text.ToLower().StartsWith(label.ToLower()))
                {
                    return true;
                }
            }

            return false;
        }
    }
}
