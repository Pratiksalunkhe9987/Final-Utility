﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;
using System.IO;
using System.Reflection;
using System.Drawing;
using Microsoft.Office.Interop.Word;
using System.Text.RegularExpressions;

namespace ExcelAddInbulletins
{
    internal class getweeklylistsheet
    {
        /*public void FormatWeeklyListExcelFile()
        {
            try
            {
                // Get the directory where the text files are located
                string directoryPath = @"C:\Users\psalunkhe\Desktop\Macro\Weekly List";

                // Get the most recent text file in the directory
                string[] textFiles = Directory.GetFiles(directoryPath, "*.txt");
                if (textFiles.Length == 0)
                {
                    MessageBox.Show("No text files found in the directory.");
                    return;
                }

                string mostRecentFile = textFiles.OrderByDescending(f => new FileInfo(f).LastWriteTime).First();

                // Create a new Excel application
                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = true;

                // Add a new workbook
                Excel.Workbook workbook = excelApp.Workbooks.Add();
                Excel.Worksheet worksheet = workbook.ActiveSheet;

                // Read the contents of the text file
                string[] lines = File.ReadAllLines(mostRecentFile);

                // Write the contents to the Excel worksheet
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] columns = lines[i].Split('|'); // Assuming pipe-separated values

                    for (int j = 0; j < columns.Length; j++)
                    {
                        worksheet.Cells[i + 1, j + 1] = columns[j];
                    }
                }

                // Adjust column widths to fit the content
                worksheet.Columns.AutoFit();

                // Save the Excel file with a specific name pattern
                string currentDate = DateTime.Now.ToString("dd MMMM yyyy");
                string fileName = "Service Bulletins " + currentDate + ".xlsx";
                string filePath = Path.Combine(directoryPath, fileName);
                workbook.SaveAs(filePath);

                // Display a message
                MessageBox.Show("Excel file saved successfully with name: " + fileName);

                // Release Excel COM objects
                System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show("Error opening Excel file: " + ex.Message);
            }
        }*/

        public void FormatWeeklyListExcelFile()
        {
            try
            {
                // Get the directory where the text files are located
                string directoryPath = DirectoryPath.proximafiledirectory;

                // Get the most recent text file in the directory
                string[] textFiles = Directory.GetFiles(directoryPath, "*.txt");
                if (textFiles.Length == 0)
                {
                    MessageBox.Show("No text files found in the directory.");
                    return;
                }

                string mostRecentFile = textFiles.OrderByDescending(f => new FileInfo(f).LastWriteTime).First();

                // Create a new Excel application
                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = true;

                // Add a new workbook
                Excel.Workbook workbook = excelApp.Workbooks.Add();

                // Add a new worksheet with the name "Weekly List"
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets.Add();
                worksheet.Name = "Weekly List";

                // Read the contents of the text file
                string[] lines = File.ReadAllLines(mostRecentFile);

                // Write the contents to the Excel worksheet
                for (int i = 0; i < lines.Length; i++)
                {
                    string[] columns = lines[i].Split('|'); // Assuming pipe-separated values

                    for (int j = 0; j < columns.Length; j++)
                    {
                        // Remove leading and trailing quotes if present
                        string cleanedValue = columns[j].TrimStart('"').TrimEnd('"');

                        // Replace double quotes with a single quote
                        cleanedValue = cleanedValue.Replace("\"\"", "\"");

                        // Write the cleaned value to the Excel worksheet
                        worksheet.Cells[i + 1, j + 1] = cleanedValue;
                    }
                }

                // Adjust column widths to fit the content
                worksheet.Columns.AutoFit();

                // Save the Excel file with a specific name pattern
                string currentDate = DateTime.Now.ToString("dd MMMM yyyy");
                string fileName = "Service Bulletins " + currentDate + ".xlsx";
                string filePath = Path.Combine(directoryPath, fileName);
                workbook.SaveAs(filePath);

                // Display a message
                MessageBox.Show("Excel file saved successfully with name: " + fileName);
                //DirectoryPath.CloseAllReadOnlyWorkbooks();  
                // Close the workbook and release Excel COM objects
                workbook.Close();
                excelApp.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(worksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);

                // Add the "Final SD Download" sheet to the newly created Excel file

            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show("Error opening Excel file: " + ex.Message);
            }
        }

        public void AddFinalSDDownloadSheet()
        {
            try
            {
                // Source file path
                string sourceFilePath = DirectoryPath.AbsentSD;

                // Get the directory where the destination files are located
                string directoryPath = DirectoryPath.proximafiledirectory;

                // Generate destination file path based on the current date
                string currentDate = DateTime.Now.ToString("dd MMMM yyyy");
                string fileName = "Service Bulletins " + currentDate + ".xlsx";
                string destinationFilePath = Path.Combine(directoryPath, fileName);

                // Open the source Excel file containing the "Final SD Download" sheet
                Excel.Application excelApp = new Excel.Application();
                Excel.Workbook sourceWorkbook = excelApp.Workbooks.Open(sourceFilePath);
                Excel.Worksheet finalSDWorksheet = sourceWorkbook.Sheets["Final SD Download List"];

                // Open the target Excel file
                Excel.Workbook targetWorkbook = excelApp.Workbooks.Open(destinationFilePath);

                // Copy the "Final SD Download" sheet to the target workbook
                finalSDWorksheet.Copy(After: targetWorkbook.Sheets[targetWorkbook.Sheets.Count]);

                // Get reference to the copied sheet
                Excel.Worksheet copiedWorksheet = targetWorkbook.Sheets[targetWorkbook.Sheets.Count];

                // Rename the copied sheet as "Summary Modified"
                copiedWorksheet.Name = "Summary Modified";

                // Set wrap text property to false for all cells in the "Summary Modified" sheet
                foreach (Excel.Range cell in copiedWorksheet.UsedRange.Cells)
                {
                    cell.WrapText = false;
                }

                // Autofit columns in the "Summary Modified" sheet
                copiedWorksheet.Columns.AutoFit();

                // Save changes to the target workbook
                targetWorkbook.Save();

                // Close the workbooks and release Excel COM objects
                sourceWorkbook.Close();
                targetWorkbook.Close();
                //DirectoryPath.CloseAllReadOnlyWorkbooks();
                excelApp.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(copiedWorksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(finalSDWorksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(sourceWorkbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(targetWorkbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show("Error adding Final SD Download sheet: " + ex.Message);
            }
        }


        /*public void combinedfinalsheet()
        {
            string directoryPath = @"C:\Users\psalunkhe\Desktop\Macro\Weekly List";
            // Path to the input Excel file

            string currentDate = DateTime.Now.ToString("dd MMMM yyyy");
            string fileName = "Service Bulletins " + currentDate + ".xlsx";
            string inputFilePath = Path.Combine(directoryPath, fileName);
            

            // Specify the columns to extract from each sheet
            int[] weeklyListColumns = { 1, 5, 9, 10 }; // Example: columns A, B, and C from Weekly List sheet
            int[] summaryModifiedColumns = { 2, 3, 7 }; // Example: columns A, D, and E from Summary Modified sheet

            // Add a new sheet in the existing workbook and populate it with combined data
            AddNewSheet(inputFilePath, "Combined Data", "Weekly List", weeklyListColumns, "Summary Modified", summaryModifiedColumns);
        }

        static void AddNewSheet(string inputFilePath, string newSheetName, string sheetName1, int[] columns1, string sheetName2, int[] columns2)
        {
            // Create Excel application
            Excel.Application excelApp = new Excel.Application();
            excelApp.Visible = true;

            // Open the input workbook
            Excel.Workbook workbook = excelApp.Workbooks.Open(inputFilePath);

            try
            {
                // Create a new worksheet for the combined data
                Excel.Worksheet newWorksheet = (Excel.Worksheet)workbook.Sheets.Add();

                // Rename the new worksheet
                newWorksheet.Name = newSheetName;

                // Get the worksheets
                Excel.Worksheet worksheet1 = (Excel.Worksheet)workbook.Sheets[sheetName1];
                Excel.Worksheet worksheet2 = (Excel.Worksheet)workbook.Sheets[sheetName2];

                // Copy columns from the first sheet to the new worksheet
                CopyColumns(worksheet1, newWorksheet, columns1, 1);

                // Copy columns from the second sheet to the new worksheet
                CopyColumns(worksheet2, newWorksheet, columns2, columns1.Length + 1);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                // Save changes to the workbook
                workbook.Save();

                // Close the workbook and release Excel COM objects
                workbook.Close();
                excelApp.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
            }
        }

        static void CopyColumns(Excel.Worksheet sourceWorksheet, Excel.Worksheet destinationWorksheet, int[] columnsToCopy, int startColumn)
        {
            foreach (int column in columnsToCopy)
            {
                Excel.Range sourceColumn = (Excel.Range)sourceWorksheet.Columns[column];
                Excel.Range destinationColumn = (Excel.Range)destinationWorksheet.Columns[startColumn];
                sourceColumn.Copy(destinationColumn);
                startColumn++;
            }
        }*/


        /* public void combinedfinalsheet()
         {
             string directoryPath = @"C:\Users\psalunkhe\Desktop\Macro\Weekly List";
             try
             {
                 string currentDate = DateTime.Now.ToString("dd MMMM yyyy");
                 string fileName = "Service Bulletins " + currentDate + ".xlsx";
                 string filePath = Path.Combine(directoryPath, fileName);
                 // Create Excel application
                 Excel.Application excelApp = new Excel.Application();
                 excelApp.Visible = true;

                 // Open the workbook
                 Excel.Workbook workbook = excelApp.Workbooks.Open(filePath);

                 // Create a new worksheet
                 Excel.Worksheet newWorksheet = (Excel.Worksheet)workbook.Sheets.Add();
                 newWorksheet.Name = "Combined Data";

                 // Specify the columns to copy from the "Weekly List" sheet
                 int[] columnsToCopy = { 1, 5, 9, 10 }; // IssueID, Module, Summary, CRDD Reqd, External text, Internal text

                 // Get the "Weekly List" worksheet
                 Excel.Worksheet weeklyListSheet = (Excel.Worksheet)workbook.Sheets["Weekly List"];

                 // Copy data from "Weekly List" sheet to the new worksheet
                 CopyColumns(weeklyListSheet, newWorksheet, columnsToCopy, 1);

                 // Save changes to the workbook
                 workbook.Save();

                 // Close the workbook and release Excel COM objects
                 workbook.Close();
                 excelApp.Quit();
                 System.Runtime.InteropServices.Marshal.ReleaseComObject(newWorksheet);
                 System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                 System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
             }
             catch (Exception ex)
             {
                 // Handle any exceptions
                 MessageBox.Show("Error: " + ex.Message);
             }
         }

         static void CopyColumns(Excel.Worksheet sourceWorksheet, Excel.Worksheet destinationWorksheet, int[] columnsToCopy, int startColumn)
         {
             foreach (int column in columnsToCopy)
             {
                 Excel.Range sourceColumn = (Excel.Range)sourceWorksheet.Columns[column];
                 Excel.Range destinationColumn = (Excel.Range)destinationWorksheet.Columns[startColumn];
                 sourceColumn.Copy(destinationColumn);
                 startColumn++;
             }
         }*/

        public void combinedfinalsheet()
        {
            string directoryPath = DirectoryPath.proximafiledirectory;
            try
            {
                string currentDate = DateTime.Now.ToString("dd MMMM yyyy");
                string fileName = "Service Bulletins " + currentDate + ".xlsx";
                string filePath = Path.Combine(directoryPath, fileName);

                // Create Excel application
                Excel.Application excelApp = new Excel.Application();
                excelApp.Visible = true;

                // Open the workbook
                Excel.Workbook workbook = excelApp.Workbooks.Open(filePath);

                // Create a new worksheet
                Excel.Worksheet newWorksheet = (Excel.Worksheet)workbook.Sheets.Add();
                newWorksheet.Name = "Combined Data";

                // Specify the columns to copy from the "Weekly List" sheet
                int[] columnsToCopy = { 1, 5, 9, 10 }; // IssueID, Module, Summary, CRDD Reqd, External text, Internal text

                // Get the "Weekly List" and "Summary Modified" worksheets
                Excel.Worksheet weeklyListSheet = (Excel.Worksheet)workbook.Sheets["Weekly List"];
                Excel.Worksheet summaryModifiedSheet = (Excel.Worksheet)workbook.Sheets["Summary Modified"];

                // Copy data from "Weekly List" sheet to the new worksheet
                CopyColumns(weeklyListSheet, newWorksheet, columnsToCopy, 1);

                // Get the last used row in the new worksheet
                int lastRow = newWorksheet.Cells[newWorksheet.Rows.Count, 1].End(Excel.XlDirection.xlUp).Row + 1;

                // Copy data from "Summary Modified" sheet to the new worksheet based on matching IssueID
                CopyDataByIssueID(summaryModifiedSheet, newWorksheet, 1, 2);

                RemoveSpecialCharacters(newWorksheet);


                // Save changes to the workbook
                workbook.Save();

                // Close the workbook and release Excel COM objects
                workbook.Close();
                //DirectoryPath.CloseAllReadOnlyWorkbooks();
                excelApp.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(newWorksheet);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(workbook);
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        static void CopyColumns(Excel.Worksheet sourceWorksheet, Excel.Worksheet destinationWorksheet, int[] columnsToCopy, int startColumn)
        {
            foreach (int column in columnsToCopy)
            {
                Excel.Range sourceColumn = sourceWorksheet.Columns[column];
                Excel.Range destinationColumn = destinationWorksheet.Columns[startColumn];

                sourceColumn.Copy();
                destinationColumn.PasteSpecial(Excel.XlPasteType.xlPasteValues);

                // Increment the startColumn for the next iteration
                startColumn++;
            }
        }

        static void CopyDataByIssueID(Excel.Worksheet sourceWorksheet, Excel.Worksheet destinationWorksheet, int issueIdColumnIndex, int startColumn)
        {
            // Get the last used row in the source worksheet
            int lastRow = sourceWorksheet.Cells[sourceWorksheet.Rows.Count, 1].End(Excel.XlDirection.xlUp).Row;

            // Get the last used column in the destination worksheet
            int lastColumn = destinationWorksheet.Cells[1, destinationWorksheet.Columns.Count].End(Excel.XlDirection.xlToLeft).Column + 1;

            // Loop through each row in the source worksheet
            for (int i = 1; i <= lastRow; i++) // Assuming row 1 contains headers
            {
                // Get the IssueID from the source worksheet
                string issueId = sourceWorksheet.Cells[i, issueIdColumnIndex].Value.ToString();

                // Find the corresponding row in the destination worksheet based on IssueID
                Excel.Range issueIdRange = destinationWorksheet.Columns[1].Find(issueId, Type.Missing,
                                        Excel.XlFindLookIn.xlValues,
                                        Excel.XlLookAt.xlWhole,
                                        Excel.XlSearchOrder.xlByRows,
                                        Excel.XlSearchDirection.xlNext, false, Type.Missing, Type.Missing);

                // If IssueID is found in the destination worksheet, copy the data
                if (issueIdRange != null)
                {
                    // Copy data from source worksheet to destination worksheet starting from the last column + 1
                    destinationWorksheet.Cells[issueIdRange.Row, lastColumn].Value = sourceWorksheet.Cells[i, 2].Value;
                    destinationWorksheet.Cells[issueIdRange.Row, lastColumn + 1].Value = sourceWorksheet.Cells[i, 3].Value;
                    destinationWorksheet.Cells[issueIdRange.Row, lastColumn + 2].Value = sourceWorksheet.Cells[i, 7].Value;
                }
            }
        }
        static void RemoveSpecialCharacters(Excel.Worksheet worksheet)
        {
            Excel.Range usedRange = worksheet.UsedRange;
            foreach (Excel.Range cell in usedRange)
            {
                if (cell.Value != null)
                {
                    string cellValue = cell.Value.ToString();
                    string cleanedValue = RemoveNonAsciiCharacters(cellValue);
                    cell.Value = cleanedValue;
                }
            }
        }

        static string RemoveNonAsciiCharacters(string value)
        {
            // Regular expression to match non-ASCII characters
            string pattern = @"[^\u0000-\u007F]";
            // Replace non-ASCII characters with an empty string
            string cleanedValue = Regex.Replace(value, pattern, "");
            return cleanedValue;
        }





        public void finalformat()
        {
            string directoryPath = DirectoryPath.proximafiledirectory;
            try
            {
                // Get all Excel files in the directory
                string[] excelFiles = Directory.GetFiles(directoryPath, "*.xlsx");

                // Sort the files based on creation time in descending order
                Array.Sort(excelFiles, (a, b) => new FileInfo(b).CreationTime.CompareTo(new FileInfo(a).CreationTime));

                if (excelFiles.Length > 0)
                {
                    // Open the most recent Excel file
                    Excel.Application excelApp = new Excel.Application();
                    excelApp.Visible = true;
                    Excel.Workbook workbook = excelApp.Workbooks.Open(excelFiles[0]);

                    // Call the FormatWorksheet method and pass the worksheet name
                    FormatWorksheet(workbook, "Combined Data");
                }
                else
                {
                    // No Excel files found in the directory
                    MessageBox.Show("No Excel files found in the directory.");
                }
                //DirectoryPath.CloseAllReadOnlyWorkbooks();  
            }
            catch (Exception ex)
            {
                // Handle any exceptions
                MessageBox.Show("Error: " + ex.Message);
            }
        }
        private void FormatWorksheet(Excel.Workbook workbook, string sheetName)
        {
            try
            {
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Sheets[sheetName];

                // Get the range corresponding to the header rows (assuming header is in the first row)
                Excel.Range headerRange = worksheet.Rows[1];

                // Set background color to light green for the header range only
                headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGreen);

                // Make header bold
                headerRange.Font.Bold = true;

                // Add borders to the header range
                headerRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                headerRange.Borders.Weight = Excel.XlBorderWeight.xlMedium;

                // Your remaining formatting code here

                // Remove wrap text formatting
                Excel.Range dataRange = worksheet.UsedRange;
                dataRange.WrapText = false;

                // Retain alignment and font settings for data range
                dataRange.HorizontalAlignment = Excel.Constants.xlLeft;
                dataRange.VerticalAlignment = Excel.Constants.xlCenter;
                dataRange.Font.Name = "Calibri";
                dataRange.Font.Size = 11;

                // Remove unwanted spaces from data
                foreach (Excel.Range cell in dataRange)
                {
                    // Trim leading and trailing spaces from the cell value
                    cell.Value = cell.Value?.ToString().Trim();
                }

                // Autofit columns in the data range
                dataRange.Columns.AutoFit();

                // Add borders to the entire content range
                dataRange.Borders.LineStyle = Excel.XlLineStyle.xlContinuous;
                dataRange.Borders.Weight = Excel.XlBorderWeight.xlThin;

                // Set background color to hex color #A9D08E for the header range
                Color hexColor = ColorTranslator.FromHtml("#A9D08E");
                headerRange.Interior.Color = System.Drawing.ColorTranslator.ToOle(hexColor);

                // Change the position of columns 5 and 6 to positions 2 and 3
                Excel.Range column5 = (Excel.Range)dataRange.Columns[5];
                Excel.Range column6 = (Excel.Range)dataRange.Columns[6];

                column5.Cut();
                Excel.Range destinationColumn2 = (Excel.Range)dataRange.Columns[2];
                destinationColumn2.Insert(Excel.XlInsertShiftDirection.xlShiftToRight);

                column6.Cut();
                Excel.Range destinationColumn3 = (Excel.Range)dataRange.Columns[3];
                destinationColumn3.Insert(Excel.XlInsertShiftDirection.xlShiftToRight);

                workbook.Save();

               
                Excel.Application excelApp = workbook.Application;
                excelApp.Quit();
                System.Runtime.InteropServices.Marshal.ReleaseComObject(excelApp);
                
                // Save changes to the worksheet (optional)
                // worksheet.Parent.Save(); // Uncomment this line if you want to save changes immediately
            }
            catch (Exception ex)
            {
                // Handle formatting errors
                MessageBox.Show("Error formatting worksheet: " + ex.Message);
            }
        }
        

    }
}
