﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelAddInbulletins
{
    internal class sheets2
    {
        List<string> existIds = new List<string>();
        List<string> issueIds = new List<string>();
        List<string> presentIds = new List<string>();
        List<string> totalIds = new List<string>();
        public void CopyHeaderToUnderscoreSDWorksheet()
        {
            Excel.Workbook workbook = Globals.ThisAddIn.Application.ActiveWorkbook;

            if (workbook == null)
            {
                MessageBox.Show("No active workbook found.");
                return;
            }

            Excel.Worksheet sourceWorksheet = workbook.Sheets["Remove_Redundant_Column "];
            Excel.Worksheet underscoreSDWorksheet = null;

            // Check if the underscoreSDWorksheet exists, if not, add it
            try
            {
                underscoreSDWorksheet = workbook.Sheets["Check Underscore & SD download"];
            }
            catch
            {
                // underscoreSDWorksheet doesn't exist, so add it
                underscoreSDWorksheet = (Excel.Worksheet)workbook.Sheets.Add();
                underscoreSDWorksheet.Name = "Check Underscore & SD download";
            }

            if (sourceWorksheet == null)
            {
                MessageBox.Show("Source worksheet not found.");
                return;
            }

            Excel.Range sourceHeaderRow = sourceWorksheet.Rows[1]; // Get the first row (header) of the source worksheet
            Excel.Range destinationHeaderRow = underscoreSDWorksheet.Rows[1]; // Get the first row of the destination worksheet

            sourceHeaderRow.Copy(destinationHeaderRow); // Copy the header row to the destination worksheet

            Excel.Range allCells = underscoreSDWorksheet.Cells;
            Excel.Borders borders = allCells.Borders;
            borders.LineStyle = Excel.XlLineStyle.xlContinuous;
            borders.Weight = Excel.XlBorderWeight.xlThin;

            MessageBox.Show("Header copied from Source to 'Check Underscore & SD download' sheet.");


            ExcelReader obj1 = new ExcelReader();
            issueIds = obj1.ReadIssueIds();
            CheckIds obj2 = new CheckIds();
            foreach (string id in issueIds)
            {
                Console.WriteLine(id);
                existIds = obj2.CheckFiles(id);
            }

            totalIds = CombineLists(issueIds, existIds);

            AddIds(totalIds, "Check Underscore & SD download");
            CopyDataToFinal_SD_Download_List();
            //mark the red colour for missing issue ids
            foreach (string id in issueIds)
            {
                presentIds = obj2.CheckFilesfromdocuments(id);
            }

            UpdateComponentBasedOnIssueId(underscoreSDWorksheet);

            obj2.MarkAbsentData(existIds);
        }


        public List<string> getpresentids()
        {
            return presentIds;
        }

        public static List<T> CombineLists<T>(List<T> list1, List<T> list2)
        {
            return list1.Union(list2).ToList();
        }


        public void AddIds(List<string> issueIds, string worksheetName)
        {
            // Sort the issue IDs
            issueIds.Sort(new IssueIdComparer());

            Excel.Workbook workbook = Globals.ThisAddIn.Application.ActiveWorkbook;

            if (workbook == null)
            {
                MessageBox.Show("No active workbook found.");
                return;
            }

            Excel.Worksheet underscoreSDWorksheet = null;

            try
            {
                underscoreSDWorksheet = workbook.Sheets[worksheetName];
            }
            catch
            {
                MessageBox.Show($"{worksheetName} sheet not found.");
                return;
            }

            // Get the index of the "Issue ID" column
            int issueIdColumnIndex = GetIssueIdColumnIndex(underscoreSDWorksheet);

            if (issueIdColumnIndex == -1)
            {
                MessageBox.Show("Issue ID column not found.");
                return;
            }

            // Find the last used row in the "Issue ID" column
            int lastRow = underscoreSDWorksheet.Cells[underscoreSDWorksheet.Rows.Count, issueIdColumnIndex].End[Excel.XlDirection.xlUp].Row;

            // Start adding IDs from the next row
            int startRow = lastRow + 1;

            // Write issue IDs to the specified worksheet
            for (int i = 0; i < issueIds.Count; i++)
            {
                Excel.Range cell = (Excel.Range)underscoreSDWorksheet.Cells[startRow + i, issueIdColumnIndex];
                cell.Value = issueIds[i];
            }

            MessageBox.Show($"Sorted and added issue IDs to the '{worksheetName}' sheet.");

            //DirectoryPath.CloseAllReadOnlyWorkbooks();
        }



        private int GetIssueIdColumnIndex(Excel.Worksheet worksheet)
        {
            int columnIndex = -1;
            Excel.Range firstRow = worksheet.Rows[1];

            foreach (Excel.Range cell in firstRow.Cells)
            {
                if (cell.Value != null && cell.Value.ToString() == "IssueID")
                {
                    columnIndex = cell.Column;
                    break;
                }
            }

            return columnIndex;
        }



        public void UpdateComponentBasedOnIssueId(Excel.Worksheet worksheet)
        {
            int rowCount = worksheet.Cells[worksheet.Rows.Count, "A"].End(Excel.XlDirection.xlUp).Row;

            for (int m = 2; m <= rowCount; m++)
            {
                string issueId = worksheet.Cells[m, "A"].Value.ToString();

                if (issueId.Contains("SER"))
                {
                    worksheet.Cells[m, "B"].Value = "Service";
                }
                else if (issueId.Contains("PRT"))
                {
                    worksheet.Cells[m, "B"].Value = "Parts";
                }
                else if (issueId.Contains("REN"))
                {
                    worksheet.Cells[m, "B"].Value = "Rental";
                }
                else if (issueId.Contains("EQP"))
                {
                    worksheet.Cells[m, "B"].Value = "Equipment";
                }
                else if (issueId.Contains("FIN"))
                {
                    worksheet.Cells[m, "B"].Value = "Finance";
                }
                else if (issueId.Contains("INT"))
                {
                    worksheet.Cells[m, "B"].Value = "Integration";
                }
            }
        }


        public void CopyDataToFinal_SD_Download_List()
        {
            Excel.Workbook workbook = Globals.ThisAddIn.Application.ActiveWorkbook;

            if (workbook == null)
            {
                MessageBox.Show("No active workbook found.");
                return;
            }

            Excel.Worksheet sourceWorksheet = workbook.Sheets["Remove_Redundant_Column "];
            Excel.Worksheet finalSDWorksheet = null;

            try
            {
                finalSDWorksheet = workbook.Sheets["Check Underscore & SD download"];
            }
            catch
            {
                finalSDWorksheet = (Excel.Worksheet)workbook.Sheets.Add();
                finalSDWorksheet.Name = "Check Underscore & SD download";
            }

            if (sourceWorksheet == null)
            {
                MessageBox.Show("Source worksheet not found.");
                return;
            }

            // Get the used range of both source and final worksheets
            Excel.Range sourceRange = sourceWorksheet.UsedRange;
            Excel.Range finalRange = finalSDWorksheet.UsedRange;

            // Iterate over each row in the final worksheet
            foreach (Excel.Range finalRow in finalRange.Rows)
            {
                string finalIssueId = finalRow.Cells[1, 1]?.Value?.ToString(); // Assuming IssueID is in the first column

                if (string.IsNullOrEmpty(finalIssueId))
                {
                    continue; // Skip processing if IssueID is null or empty
                }

                // Iterate over each row in the source worksheet
                foreach (Excel.Range sourceRow in sourceRange.Rows)
                {
                    string sourceIssueId = sourceRow.Cells[1, 1]?.Value?.ToString(); // Assuming IssueID is in the first column

                    if (!string.IsNullOrEmpty(sourceIssueId))
                    {
                        // Check if the final IssueID matches an IssueID in the source sheet or is a variant
                        if (finalIssueId == sourceIssueId || finalIssueId.StartsWith(sourceIssueId + "_"))
                        {
                            // Copy all other column data from the source row to the final row
                            for (int j = 2; j <= sourceWorksheet.Columns.Count; j++) // Start from column 2 to skip the IssueID column
                            {
                                finalRow.Cells[1, j].Value = sourceRow.Cells[1, j].Value;
                            }
                            break; // Stop searching for a match once found
                        }
                    }
                }
            }
            MessageBox.Show("Data copied to 'Final SD Download List' sheet based on matching issue IDs.");
        }


    }
}
